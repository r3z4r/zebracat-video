import {
	interpolate,
	Sequence,
	spring,
	useCurrentFrame,
	useVideoConfig,
} from 'remotion';
import {AbsoluteFill} from 'remotion';
import React from 'react';
import {Clip} from '../Teaser/Clip';

export const Clips: React.FC = () => {
	const frame = useCurrentFrame();
	const {fps} = useVideoConfig();

	const rangeGenerator = (delay = 0, range: [number, number] = [0, 1]) =>
		interpolate(
			spring({
				frame: frame - delay,
				fps,
				config: {
					damping: 200,
					mass: 2,
				},
			}),
			[0, 1],
			range
		);
	return (
		<AbsoluteFill>
			<Sequence
				style={{
					opacity: rangeGenerator(),
				}}
				from={0}
				durationInFrames={125}
			>
				<Clip clipName="1.webm" />
			</Sequence>
			<Sequence
				style={{
					opacity: rangeGenerator(120),
				}}
				from={120}
				durationInFrames={85}
			>
				<Clip clipName="2.webm" />
			</Sequence>
			<Sequence
				style={{
					opacity: rangeGenerator(290, [1, 0]),
				}}
				from={200}
				durationInFrames={120}
			>
				<Clip startFrom={29} clipName="10.webm" />
			</Sequence>
		</AbsoluteFill>
	);
};
