# Zebracat Remotion video

## Soundtrack link

https://taketones.com/track/dance-with-somebody

## Commands

**Install Dependencies**

```console
npm i
```

**Start Preview**

```console
npm start
```

**Render video**

```console
npm run build
```

**Upgrade Remotion**

```console
npm run upgrade
```
